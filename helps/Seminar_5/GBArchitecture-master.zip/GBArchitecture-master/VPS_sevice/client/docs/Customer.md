# Customer

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | 
**name** | **String** |  | 
**login** | **String** | Ваш логин в ситеме | 
**password** | **String** | Ваш пароль | 
**phone** | **String** | Ваш телефон | 
**email** | **String** | Ваша почта | 
**balance** | **String** | Ваш баланс на сервисе | 
