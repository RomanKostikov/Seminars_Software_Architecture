# OS

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**osId** | **String** | ID операционки | 
**name** | **String** | название операционки | 
**osGroup** | **String** | название семейства ОS | 
**osVersion** | **String** | версия ОS | 
**language** | **String** | язык ОS | 
**price** | **String** | цена использования ОS | 
