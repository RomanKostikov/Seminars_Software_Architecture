package strategy.interfaces;

public interface iDiveable {
    void dive();
}
