package decorator.abstracts;

public abstract class Car {
    public abstract void build();
}
