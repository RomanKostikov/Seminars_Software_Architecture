package factoryMethod.interfaces;

public interface iRewardItem {
    void open();
}
