package factoryMethod.interfaces;

public interface iGiver {
    void giveReward();
}
