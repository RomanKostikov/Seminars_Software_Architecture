package observer.interfaces;

public interface iFollower {
    void update();
}
