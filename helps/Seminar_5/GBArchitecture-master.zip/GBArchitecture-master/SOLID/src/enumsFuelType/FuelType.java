package enumsFuelType;
/*
типы топлива для наших автомобилей
 */
public enum FuelType {
    GASOLINE,
    DIESEL,
    ELECTRIC,
}
