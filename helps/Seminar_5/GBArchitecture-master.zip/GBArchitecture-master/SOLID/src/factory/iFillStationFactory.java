package factory;

import interfaces.iFillStation;
// интерфейс фабрик
public interface iFillStationFactory {
    iFillStation createFillStation();
}
