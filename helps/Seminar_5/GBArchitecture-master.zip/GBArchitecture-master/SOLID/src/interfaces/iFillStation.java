package interfaces;
/*
Создать интерфейс «Заправочная станция», создать метод: заправка топливом.
 */
public interface iFillStation {
    void fill();
}
