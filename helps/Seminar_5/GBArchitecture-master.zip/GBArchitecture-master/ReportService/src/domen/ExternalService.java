package domen;


public class ExternalService {
    public Data getDataFromExternalSystem() {
        // Реализация получения данных из внешней системы

        return data;
    }
}
