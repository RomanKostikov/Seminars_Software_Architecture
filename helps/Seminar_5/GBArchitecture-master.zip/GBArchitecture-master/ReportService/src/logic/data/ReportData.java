package logic.data;

public class ReportData {
    // Поля для представления данных отчета
}
