package logic.data;

public class ReportParameters {
    // Поля для хранения параметров отчета
}
