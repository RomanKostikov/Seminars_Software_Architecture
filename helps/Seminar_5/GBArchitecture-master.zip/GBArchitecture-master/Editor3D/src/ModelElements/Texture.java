package src.ModelElements;

public class Texture {

}
