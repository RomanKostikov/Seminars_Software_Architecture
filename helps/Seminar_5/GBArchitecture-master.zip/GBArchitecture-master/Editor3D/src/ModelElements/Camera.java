package src.ModelElements;

import src.Stuff.Angle3D;
import src.Stuff.Point3D;

public class Camera {
    public Point3D location;
    public Angle3D angle;

    /**
     *
     * @param angle3D перемещение камеры на угол
     */
    public void rotate(Angle3D angle3D) {

    }

    /**
     *
     * @param point3D перемещение камеры к точке
     */

    public void move(Point3D point3D) {

    }
}
