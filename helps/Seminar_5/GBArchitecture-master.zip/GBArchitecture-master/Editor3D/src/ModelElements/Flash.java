package src.ModelElements;

import src.Stuff.Angle3D;
import src.Stuff.Point3D;
import java.awt.*;

public class Flash {
    public Point3D location;
    public Angle3D angle;
    public Color color;
    public Float power;

    /**
     *
     * @param angle3D перемещение света на угол
     */
    public void rotate(Angle3D angle3D) {

    }

    /**
     *
     * @param point3D перемещение света к точке
     */
    public void move(Point3D point3D) {

    }

}
