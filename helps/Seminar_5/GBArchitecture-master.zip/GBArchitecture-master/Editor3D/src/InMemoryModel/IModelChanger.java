package src.InMemoryModel;

public interface IModelChanger {
    void NotifyChange(IModelChanger sender);
}
