package src.InMemoryModel;

public interface IModelChangedObserver {
    void applyUpdateModel();
}
