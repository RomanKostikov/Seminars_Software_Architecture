package InMemoryModel;


public interface IModelChanger {
    public void NotifyChange (IModelChanger sender);
}
