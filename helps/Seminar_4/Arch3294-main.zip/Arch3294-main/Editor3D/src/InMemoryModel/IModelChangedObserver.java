package InMemoryModel;

//Интерфейс смены наблюдателя
public interface IModelChangedObserver {
    public void ApplyUpdateModel ();
}
