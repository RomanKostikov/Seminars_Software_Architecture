package ModelElements;

import Staff.Angle3D;
import Staff.Point3D;

/**
 * класс камер
 */
public class Camera {
    public Point3D Location;
    public Angle3D Angle;
    /**
     * поворот камеры на угол
     *
     * @param angleAction
     */
    public void Rotate(Angle3D angleAction) {

    }

    /**
     * перемещение камеры к точке
     * @param pointAction
     */
    public void Move(Point3D pointAction){

    }
}
