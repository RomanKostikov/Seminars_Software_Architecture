package ModelElements;

public class Texture {
}
