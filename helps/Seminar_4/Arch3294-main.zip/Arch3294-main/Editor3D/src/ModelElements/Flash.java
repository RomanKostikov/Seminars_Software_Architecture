package ModelElements;

import Staff.Angle3D;
import Staff.Point3D;

/**
 * класс источников света
 */
public class Flash {
    public Point3D Location;
    public Angle3D Angle;
    public java.awt.Color color;
    public float Power;

    /**
     * поворот источников света на угол
     *
     * @param angleAction
     */
    public void Rotate(Angle3D angleAction) {

    }

    /**
     * перемещение к точке
     * @param pointAction
     */
    public void Move(Point3D pointAction){

    }
}
