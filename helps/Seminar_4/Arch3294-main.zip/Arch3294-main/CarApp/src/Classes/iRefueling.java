package Classes;

public interface iRefueling {
    void fuel();

}
