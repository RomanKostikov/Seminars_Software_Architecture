package Classes;

public enum TypeGearbox {
    AT, MT
}
