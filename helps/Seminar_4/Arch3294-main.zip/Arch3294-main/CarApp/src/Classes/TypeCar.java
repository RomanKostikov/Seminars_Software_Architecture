package Classes;

public enum TypeCar {
    SEDAN, PICKUP
}
