package Classes;

public interface iWiping {
    void wipWindshield();
    void wipHeadlights();
    void wipMirrors();
}
