package Classes;

public enum TypeFuel {
    gasoline, diesel
}
