import ClientApplication.Start;
import Services.CashRepository;

public class Main {
    public static void main(String[] args) {
        Start start = new Start();
        start.runLoginRegisterMenu();;
    }
}