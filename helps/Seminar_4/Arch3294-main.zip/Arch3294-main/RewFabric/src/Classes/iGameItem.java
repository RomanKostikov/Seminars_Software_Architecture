package Classes;

public interface iGameItem{
    void open();
}